
public class author {

	private String fname;
	private String lname;
	private String email;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		if(fname.contains("[")) {
			fname=fname.substring(1, fname.length()-1);
		}
		this.fname = fname.trim();
	}
	public String getLname() {
		
		return lname;
	}
	public void setLname(String lname) {
		if(lname.contains("]")) {
			lname=lname.substring(0, lname.length()-2);
		}
		this.lname = lname.trim();
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
