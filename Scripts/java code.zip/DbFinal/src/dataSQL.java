import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import org.bson.Document;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;
import com.mongodb.WriteConcern;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class dataSQL {

	public static void main(String[] args) throws IOException, JSchException {

		readCSV rCSV = new readCSV();
		List<Map<String, Object>> articleList = new ArrayList<>();
		List<Map<String, Object>> authorList = new ArrayList<>();
		java.util.logging.Logger.getLogger("JULLogger").setLevel(Level.OFF);
		final String LOCAL_HOST = "localhost";
		final String REMOTE_HOST = "127.0.0.1";
		final Integer LOCAL_PORT = 6960;
		final Integer REMOTE_PORT = 27017; //
		java.util.Properties config = new java.util.Properties();
	    config.put("StrictHostKeyChecking", "no");

BufferedReader reader =  
new BufferedReader(new InputStreamReader(System.in)); 
System.out.println("Java is trying to load data from mongo, and hence requires authentication:");
System.out.println("enter mongo db user name:");
// Reading data using readLine 
String usrName = reader.readLine(); 

System.out.println("enter mongo db password:");
String password = reader.readLine();
	    JSch jsch=new JSch();
	    final String SSH_USER = usrName;
	    final String SSH_PASSWORD = password;
	    final String SSH_HOST = "mcda5540.cs.smu.ca";
	    final Integer SSH_PORT = 22;
	    //SSH_SESSION = null;
	    Session SSH_SESSION = jsch.getSession(SSH_USER, SSH_HOST, SSH_PORT);
	    //SSH_SESSION = jsch.getSession(SSH_USER, SSH_HOST, SSH_PORT);
	    SSH_SESSION.setPassword(SSH_PASSWORD);
	    SSH_SESSION.setConfig(config);
	    SSH_SESSION.connect();
	    SSH_SESSION.setPortForwardingL(LOCAL_PORT, REMOTE_HOST, REMOTE_PORT);
	    //MongoClient mongo = new MongoClient(LOCAL_HOST, LOCAL_PORT);
	   // mongo.setReadPreference(ReadPreference.nearest());
		// MongoClient mongo = new MongoClient( "localhost" , 27017 );
		//MongoClient mongo = new MongoClient("localhost", 22);
		// MongoClient mongo = new MongoClient( "mcda5540.cs.smu.ca" , 22 );
		// Creating Credentials

	    MongoClientOptions options = MongoClientOptions.builder()
	    		.writeConcern(WriteConcern.JOURNALED).build();
	    MongoCredential credential; 
		  credential =
		  MongoCredential.createCredential(usrName, usrName,
				  password.toCharArray());
	    MongoClient mongo = new MongoClient(new ServerAddress(LOCAL_HOST, LOCAL_PORT), Arrays.asList(credential), options );
	    mongo.setReadPreference(ReadPreference.nearest());
		
		System.out.println("Connected to the database successfully");

		// Accessing the database
		MongoDatabase database = mongo.getDatabase("u32");
		
		MongoCollection<Document> articles = database.getCollection("articles");
		FindIterable<Document> iterArticle = articles.find();

		MongoCollection<Document> author = database.getCollection("author");
		FindIterable<Document> iterAuthor = author.find();

		// int i = 1;

		// Getting the iterator
		Iterator<Document> itArticle = iterArticle.iterator();
		Iterator<Document> itAuthor = iterAuthor.iterator();
		while (itAuthor.hasNext()) {
			Document document = itAuthor.next();
			document.remove("_id");
			Map<String, Object> map = new HashMap<>(document);
			authorList.add(map);
		}
		while (itArticle.hasNext()) {
			Document document = itArticle.next();
			document.remove("_id");
			Map<String, Object> map = new HashMap<>(document);
			articleList.add(map);
		}
		ArrayList<author> existingAuthors = new ArrayList<>();
		for (Map<String, Object> auth : authorList) {
			author authorfromSQL = new author();
			authorfromSQL.setFname(auth.get("fname").toString());
			authorfromSQL.setLname(auth.get("lname").toString());
			authorfromSQL.setEmail(auth.get("email").toString());
			existingAuthors.add(authorfromSQL);

		}

		ArrayList<author> authorFromArticle = new ArrayList<>();
		ArrayList<article> articleFromJson = new ArrayList<>();
		for (Map<String, Object> doc : articleList) {
			article art = new article();
			art.setJournal(doc.get("journal").toString());
			art.setTitle(doc.get("title").toString());
			art.setVolume(doc.get("volume").toString());
			art.setPages(doc.get("pages").toString());
			art.setYear(doc.get("year").toString());
			articleFromJson.add(art);
			ArrayList<author> authorArt = new ArrayList<>();
			String name = doc.get("author").toString();
			if (name.startsWith("[")) {

				String authors[] = name.trim().split(",");
				for (int i = 0; i < authors.length; i++) {
					author authorName = new author();
					String names[] = authors[i].trim().split(" ");

					if (names.length == 3) {

						authorName.setFname(names[0]);
						authorName.setLname(names[1] + " " + names[2]);
					}
					if (names.length == 2) {
						authorName.setFname(names[0]);
						authorName.setLname(names[1]);
					}
					authorFromArticle.add(authorName);
					authorArt.add(authorName);

				}
			} else {
				author authorName = new author();
				String names[] = name.trim().split(" ");
				if (names.length == 3) {
					authorName.setFname(names[0]);
					authorName.setLname(names[1] + names[2]);
				}
				if (names.length == 2) {
					authorName.setFname(names[0]);
					authorName.setLname(names[1]);
				}
				authorFromArticle.add(authorName);
				authorArt.add(authorName);
			}
			art.setAuth(authorArt);
			articleFromJson.add(art);
		}
		ArrayList<author> authorsToBeEntered = new ArrayList<>();
		for (author authFromJson : authorFromArticle) {
			boolean flag = false;
			for (author authFromSQL : existingAuthors) {
				if (authFromSQL.getFname() == null || authFromSQL.getLname() == null || authFromJson.getFname() == null
						|| authFromJson.getLname() == null) {
					continue;
				}
				if ((authFromJson.getFname().equals(authFromSQL.getFname()))
						&& (authFromJson.getLname().equals(authFromSQL.getLname()))) {
					flag = true;
					break;
				}
			}
			if (flag == false) {
				authorsToBeEntered.add(authFromJson);
			}
		}
		rCSV.writeAuthorSQL(authorsToBeEntered);
		rCSV.writeMagSQL(articleFromJson);
		rCSV.writeVolSQL(articleFromJson);
		rCSV.writeArticleSQL(articleFromJson);
		rCSV.writePublishedSQL(articleFromJson);
		SSH_SESSION.delPortForwardingL(LOCAL_PORT);
	    SSH_SESSION.disconnect();

	}

}
