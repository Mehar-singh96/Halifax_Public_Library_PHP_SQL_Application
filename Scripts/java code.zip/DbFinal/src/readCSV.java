import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
public class readCSV {
	
	void writeAuthorSQL( ArrayList<author> authors) throws IOException {
	
		//PrintWriter pw=new PrintWriter("F://Textfile/insert_authors.sql","UTF-8");
		PrintWriter pw=new PrintWriter("insert_authors.sql","UTF-8");
			StringBuilder query=new StringBuilder();
			query.append("INSERT IGNORE INTO AUTHOR (fname,lname) values");
			for(int i=0;i<authors.size();i++)
			
			{
				author auth=authors.get(i);
				//System.out.println(auth.getFname()+" "+auth.getLname());
				if(auth.getFname()!=null||auth.getLname()!=null) {
				
				if(i<authors.size()-1)
				{
					
					query.append("('"+ auth.getFname().replace("'"," ") +"','" + auth.getLname().replace("'", " ")+  "')," );
					
					
				}
				else {
					query.append("('"+ auth.getFname().replace("'"," ") +"','" + auth.getLname().replace("'", " ")+  "');" );
						
				}
				}
			}
			
			pw.println(query.toString());
			pw.close();
	}
	
	
	void writeMagSQL( ArrayList<article> art) throws IOException {
		
				//PrintWriter pw=new PrintWriter("F://Textfile/insert_mag.sql","UTF-8");
				PrintWriter pw=new PrintWriter("insert_mag.sql","UTF-8");
				StringBuilder query=new StringBuilder();
			//	INSERT IGNORE INTO magazine(name) values('Acta Inf.');
				for(article artOld:art)
				{
					query.append("INSERT IGNORE INTO MAGAZINE(name) values('" +artOld.getJournal().replace("'", " ")+"');");
				}
				
				pw.println(query.toString());
				pw.close();
		}
	
	void writeVolSQL( ArrayList<article> art) throws IOException {
		
		//PrintWriter pw=new PrintWriter("F://Textfile/insert_vol.sql","UTF-8");
		PrintWriter pw=new PrintWriter("insert_vol.sql","UTF-8");	
		StringBuilder query=new StringBuilder();
				
				for(article artOld:art)
				{
					query.append("insert IGNORE into VOLUMES (mag_id,vol_no,publication_yr) values((select _id from MAGAZINE where name='" +artOld.getJournal().replace("'", " ")+"'),"+ artOld.getVolume()+","+ artOld.getYear()+");");
				}
				
				pw.println(query.toString());
				pw.close();
		}
	
	void writeArticleSQL( ArrayList<article> art) throws IOException {
		
				//PrintWriter pw=new PrintWriter("F://Textfile/insert_article.sql","UTF-8");
				PrintWriter pw=new PrintWriter("insert_article.sql","UTF-8");
				StringBuilder query=new StringBuilder();
				
				for(article artObj:art)
				{
					String title=artObj.getTitle().replace("'", " ").replace('"', ' ');
					query.append("insert IGNORE into ARTICLES (mag_id,vol_no,title,page_num) values((select _id from MAGAZINE where name='" +artObj.getJournal().replace("'", " ")+"'),"+ artObj.getVolume()+",'"+ title+"','"+artObj.getPages()+"');");
				}
				
				pw.println(query.toString());
				pw.close();
		}
	void writePublishedSQL( ArrayList<article> art) throws IOException {
		
		//PrintWriter pw=new PrintWriter("F://Textfile/insert_published.sql","UTF-8");
		PrintWriter pw=new PrintWriter("insert_published.sql","UTF-8");
		StringBuilder query=new StringBuilder();
		
		for(article artObj:art)
		{
			String title=artObj.getTitle().replace("'", " ").replace('"', ' ');
			for(int i=0;i<artObj.getAuth().size();i++)
			{
				if(artObj.getAuth().get(i).getFname()!=null||artObj.getAuth().get(i).getLname()!=null) 
			query.append("insert ignore into PUBLISHED (article_id,author_id) values((select article_id from ARTICLES where title='" +title+"'),"+"(select _id from AUTHOR where lname= '"+artObj.getAuth().get(i).getLname().replace("'"," ")+"' and fname='"+artObj.getAuth().get(i).getFname().replace("'"," ") +"'));");
		
			}
		}
		
		pw.println(query.toString());
		pw.close();
}
	
}

